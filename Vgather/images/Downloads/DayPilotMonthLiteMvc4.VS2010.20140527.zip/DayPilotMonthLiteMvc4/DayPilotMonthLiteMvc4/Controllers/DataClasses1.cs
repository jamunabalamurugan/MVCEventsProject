namespace DayPilotMonthLiteMvc4.Controllers
{
    partial class DataClasses1DataContext
    {
    }
}
